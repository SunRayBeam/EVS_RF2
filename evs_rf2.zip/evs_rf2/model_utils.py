import os
import librosa
import numpy as np
import joblib

MODEL_PATH = os.path.join(os.path.dirname(__file__), "model.pkl")
model = joblib.load(MODEL_PATH)

def extract_features(file_path):
    y, sr = librosa.load(file_path, sr=48000)
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    spectral_centroid = librosa.feature.spectral_centroid(y=y, sr=sr)
    spectral_bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sr)
    zero_crossing = librosa.feature.zero_crossing_rate(y)

    features = np.concatenate([
        mfcc.mean(axis=1),
        [spectral_centroid.mean()],
        [spectral_bandwidth.mean()],
        [zero_crossing.mean()]
    ])
    return features

def predict_category(file_path):
    features = extract_features(file_path).reshape(1, -1)
    return model.predict(features)[0]
